<!--
#### Video doesn't play?

In most cases, this is because of your browser. The app uses HTML5 video playback. That means it can only play formats supported by your browser:

https://developer.mozilla.org/en-US/docs/Web/HTML/Supported_media_formats#Browser_compatibility

Please test this by dragging the video file into an empty tab. There's only a problem with the app if the video is working in the browser, but not in the player. When you open an issue, please supply a video that doesn't work or exact information on the codecs used.
-->

### Expected behaviour
Tell us what should happen

### Actual behaviour
Tell us what happens instead

### Steps to reproduce
1.
2.
3.
